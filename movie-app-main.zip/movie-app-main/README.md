<p align="center">
  <img src="https://logospng.org/download/react/logo-react-256.png" />
</p>

<h1 align="center">Movie App</h1>
<p align="center">A simple movie app made with React.js<p>

### Was used react useState hook for manipulate the API query
### The application get the movies from TMDB API

<h1>Preview</h1>
<a href="http://www.youtube.com/watch?feature=player_embedded&v=tbXAqFw61J8
" target="_blank"><img src="http://img.youtube.com/vi/tbXAqFw61J8/0.jpg" 
alt="IMAGE ALT TEXT HERE" width="240" height="180" border="10" /></a>
